extends CharacterBody2D
class_name Player

@export_range(1,2,1) var p : int = 1

@export var enemy : Player

@export_group("Nodes")
@export var fsm : PhysicsMachine
@export var anim_player : AnimationPlayer
@export var skeleton : Skeleton2D
@export var target_ik_l : Marker2D
@export var target_ik_r : Marker2D

const SPEED = 800.0

var is_dodging : bool = false
var is_blocking : bool = false

var direction : Vector2

func _ready() -> void:
	match p :
		1 : modulate = Color(1.0, 0.62, 0.791, 1.0)
		2 : modulate = Color(0.62, 1.0, 0.918, 1.0)
		_ : push_error("p = ", p, " is not a valid player number !")
	skeleton.set_modification_stack(skeleton.get_modification_stack().duplicate_deep())

func _input(event: InputEvent) -> void:
	fsm.machine_input(event)

func _physics_process(delta: float) -> void:
	fsm.machine_physics(delta)
